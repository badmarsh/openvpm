/**
 * OpenVPM Component Library
 * Shared reusable components for veterinary clinic websites.
 *
 * Import any component from this single entry point:
 *   import { OpeningHoursTable, ContactBlock, FearFreeBadge, BookingCTA, TestimonialCard, ServiceCard } from '@/components/openvpm'
 */

export { OpeningHoursTable } from './OpeningHoursTable'
export type { HoursRow, OpeningHoursTableProps } from './OpeningHoursTable'

export { ContactBlock } from './ContactBlock'
export type { ContactBlockProps } from './ContactBlock'

export { FearFreeBadge } from './FearFreeBadge'
export type { FearFreeBadgeVariant, FearFreeBadgeProps } from './FearFreeBadge'

export { BookingCTA } from './BookingCTA'
export type { BookingCTAVariant, BookingCTAProps } from './BookingCTA'

export { TestimonialCard } from './TestimonialCard'
export type { TestimonialSource, TestimonialCardProps } from './TestimonialCard'

export { ServiceCard } from './ServiceCard'
export type { ServiceCardVariant, ServiceCardProps } from './ServiceCard'
